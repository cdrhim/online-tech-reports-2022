# © 2020 Amazon Web Services, Inc. or its affiliates. All Rights Reserved.

# This AWS Content is provided subject to the terms of the AWS Customer Agreement
# available at http://aws.amazon.com/agreement or other written agreement between
# Customer and either Amazon Web Services, Inc. or Amazon Web Services EMEA SARL or both.

import boto3
import math
import time
import json
import datetime
import logging
import uuid
import os
from boto3.dynamodb.conditions import Key, Attr
from botocore.exceptions import ClientError

logger = logging.getLogger()
logger.setLevel(logging.INFO)


#======================================================================================================================
# Variables
#======================================================================================================================

API_CALL_NUM_RETRIES = 1
ACLMETATABLE = os.environ['ACLMETATABLE']
#CLOUDFRONT_IP_SET_ID = os.environ['CLOUDFRONT_IP_SET_ID']
ALB_IP_SET_ID = os.environ['ALB_IP_SET_ID']
ALB_IP_SET_NAME = os.environ['ALB_IP_SET_NAME']
RETENTION = os.environ['RETENTION']


#======================================================================================================================
# Auxiliary Functions
#======================================================================================================================


# Delete WAF IP set
def waf_update_ip_set(waf_type, ip_set_id, source_ip):

    waf = boto3.client('wafv2')

    for attempt in range(API_CALL_NUM_RETRIES):
        try:
            ip_set_resource = waf.get_ip_set(

                Name=ALB_IP_SET_NAME,
                Scope='REGIONAL',
                Id=ip_set_id
            )
            
            address=ip_set_resource['IPSet']['Addresses']
            address.append('%s/32'%source_ip)
            
            
            response = waf.update_ip_set(
                Name=ALB_IP_SET_NAME,
                Scope='REGIONAL',
                Id=ip_set_id,
                Description='A lot of BlackList-AutoAppend automation for SRC Security Project',
                Addresses=address,
                LockToken=ip_set_resource['LockToken'])
            logger.info('successfully deleted ip %s' %source_ip)
        except Exception as e:
            logger.error(e)
            delay = math.pow(2, attempt)
            logger.info("log -- waf_delete_ip_set retrying in %d seconds..." % (delay))
            time.sleep(delay)
        else:
            break
    else:
        logger.info("log -- waf_delete_ip_set failed ALL attempts to call WAF API")

def delete_netacl_rule(netacl_id, rule_no):

    ec2 = boto3.resource('ec2')
    network_acl = ec2.NetworkAcl(netacl_id)

    try:
        response = network_acl.delete_entry(
            Egress=False,
            RuleNumber=int(rule_no)
        )
        if response['ResponseMetadata']['HTTPStatusCode'] == 200:
            logger.info('log -- delete_netacl_rule successful')
            return True
        else:
            logger.error('log -- delete_netacl_rule FAILED')
            logger.info(response)
            return False
    except Exception as e:
        logger.error(e)


def delete_ddb_rule(netacl_id, created_at):

    ddb = boto3.resource('dynamodb')
    table = ddb.Table(ACLMETATABLE)
    timestamp = int(time.time())

    response = table.delete_item(
        Key={
            'NetACLId': netacl_id,
            'CreatedAt': int(created_at)
            }
        )

    if response['ResponseMetadata']['HTTPStatusCode'] == 200:
        logger.info('log -- delete_ddb_rule successful')
        return True
    else:
        logger.error('log -- delete_ddb_rule FAILED')
        logger.info(response['ResponseMetadata'])
        return False


#======================================================================================================================
# Lambda Entry Point
#======================================================================================================================


def lambda_handler(event, context):

    #logger.info("log -- Event: %s " % json.dumps(event))

    try:
        # timestamp is calculated in seconds
        expire_time = int(time.time()) - (int(RETENTION)*60)
        logger.info("log -- expire_time = %s" % expire_time)

        #scan the ddb table to find expired records
        ddb = boto3.resource('dynamodb')
        table = ddb.Table(ACLMETATABLE)
        response = table.scan(FilterExpression=Attr('CreatedAt').lt(expire_time) & Attr('Region').eq(os.environ['AWS_REGION']))

        if response['Items']:
            logger.info("log -- attempting to prune entries, %s." % (response)['Items'])

            # process each expired record
            for item in response['Items']:
                logger.info("deleting item: %s" %item)
                logger.info("HostIp %s" %item['HostIp'])
                HostIp = item['HostIp']
                try:
                    logger.info('log -- deleting netacl rule')
                    delete_netacl_rule(item['NetACLId'], item['RuleNo'])

                    # check if IP is also recorded in a fresh finding, don't remove IP from blacklist in that case
                    response_nonexpired = table.scan( FilterExpression=Attr('CreatedAt').gt(expire_time) & Attr('HostIp').eq(HostIp) )
                    if len(response_nonexpired['Items']) == 0:
                        # no fresher entry found for that IP
                        logger.info('log -- deleting ALB WAF ip entry')
                        waf_update_ip_set('alb', ALB_IP_SET_ID, HostIp)
                        # logger.info('log -- deleting CloudFront WAF ip entry')
                        # waf_update_ip_set('cloudfront', CLOUDFRONT_IP_SET_ID, HostIp)

                    logger.info('log -- deleting dynamodb item')
                    delete_ddb_rule(item['NetACLId'], item['CreatedAt'])

                except Exception as e:
                    logger.error(e)
                    logger.error('log -- could not delete item')

            logger.info("Pruning Completed")
                
        else:
            logger.info("log -- no etntries older than %s hours... exiting GD2ACL pruning." % (int(RETENTION)/60))

    except Exception as e:
        logger.error('something went wrong')
        raise
